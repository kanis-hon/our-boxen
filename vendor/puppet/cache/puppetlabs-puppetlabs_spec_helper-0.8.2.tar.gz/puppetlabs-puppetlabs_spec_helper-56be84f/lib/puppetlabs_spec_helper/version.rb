module PuppetlabsSpecHelper
  module Version
    STRING = '0.8.2'
  end
end
