require 'puppet/type'

Puppet::Type.newtype(:spechelper) do
  @doc = "This is the spechelper type"
end

